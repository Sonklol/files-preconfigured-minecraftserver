#!/bin/bash
screen -dm bash -c "screen -s 'Minecraft Server'  java -Xms1G -Xmx6G -jar /home/MServer/minecraft_server.1.17.1.jar nogui"